package incendios.Modelo;

public class RecursoPesado extends Recurso {
    private String modeloVehiculo;
    private float capacidadCarga;
    private String tipoVehiculo;   // Autobomba, Camion cisterna

    public RecursoPesado(int idRecurso, String estado, String ubicacion,
                         String modeloVehiculo, float capacidadCarga, String tipoVehiculo) {
        super(idRecurso, "Pesado", estado, ubicacion);
        this.modeloVehiculo = modeloVehiculo;
        this.capacidadCarga = capacidadCarga;
        this.tipoVehiculo = tipoVehiculo;
    }

    public void operarRecursoPesado() { utilizarRecurso(); }

    public String transportarCarga() {
        return tipoVehiculo + " " + modeloVehiculo + " transporta hasta " + capacidadCarga + " L";
    }

    public String getModeloVehiculo() { return modeloVehiculo; }
    public void setModeloVehiculo(String modeloVehiculo) { this.modeloVehiculo = modeloVehiculo; }
    public float getCapacidadCarga() { return capacidadCarga; }
    public void setCapacidadCarga(float capacidadCarga) { this.capacidadCarga = capacidadCarga; }
    public String getTipoVehiculo() { return tipoVehiculo; }
    public void setTipoVehiculo(String tipoVehiculo) { this.tipoVehiculo = tipoVehiculo; }
}

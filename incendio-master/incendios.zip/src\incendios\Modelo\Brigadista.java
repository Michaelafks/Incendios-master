package incendios.Modelo;

public class Brigadista {
    private int idBrigadista;
    private String nombre;
    private String especialidad;
    private String estado;              // Apto, Fatiga Leve, Lesionado/No Apto
    private Brigada brigadaAsignada;    // get/set

    public Brigadista(int idBrigadista, String nombre, String especialidad, String estado) {
        this.idBrigadista = idBrigadista;
        this.nombre = nombre;
        this.especialidad = especialidad;
        this.estado = estado;
    }

    public void asistirAIncendio() {
        if (brigadaAsignada != null && brigadaAsignada.getIncendio() != null) {
            System.out.println(nombre + " asiste al incendio #" + brigadaAsignada.getIncendio().getIdIncendio());
        }
    }

    public void realizarFuncion() {
        System.out.println(nombre + " realiza su funcion como " + especialidad);
    }

    public String reportarEstado() {
        return nombre + " (" + especialidad + ") - " + estado;
    }

    public void actualizarUbicacion(String ubicacion) {
        if (brigadaAsignada != null) brigadaAsignada.setUbicacionActual(ubicacion);
    }

    public int getIdBrigadista() { return idBrigadista; }
    public void setIdBrigadista(int idBrigadista) { this.idBrigadista = idBrigadista; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getEspecialidad() { return especialidad; }
    public void setEspecialidad(String especialidad) { this.especialidad = especialidad; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    public Brigada getBrigadaAsignada() { return brigadaAsignada; }
    public void setBrigadaAsignada(Brigada brigadaAsignada) { this.brigadaAsignada = brigadaAsignada; }
}

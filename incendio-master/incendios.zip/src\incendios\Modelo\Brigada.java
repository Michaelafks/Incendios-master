package incendios.Modelo;

import java.util.ArrayList;
import java.util.List;

public class Brigada {
    private int idBrigada;
    private String nombreBrigada;
    private String ubicacionActual;
    private String estado;          // Disponible, Movilizada, Descanso
    private int capacidadTotal;

    // Relaciones
    private Incendio incendio;                              // solo get/set (lado liviano)
    private List<Brigadista> brigadistas = new ArrayList<>(); // 1 -> 0..*
    private List<Recurso> recursos = new ArrayList<>();       // 1 -> 0..*

    public Brigada(int idBrigada, String nombreBrigada, String ubicacionActual, String estado, int capacidadTotal) {
        this.idBrigada = idBrigada;
        this.nombreBrigada = nombreBrigada;
        this.ubicacionActual = ubicacionActual;
        this.estado = estado;
        this.capacidadTotal = capacidadTotal;
    }

    public void movilizar() { this.estado = "Movilizada"; }
    public void desmovilizar() { this.estado = "Disponible"; }

    public void asignarIncendio(Incendio incendio) {
        incendio.agregarBrigada(this);
    }

    public String informarEstado() {
        return "Brigada " + nombreBrigada + " [" + estado + "] en " + ubicacionActual
                + " | brigadistas: " + brigadistas.size();
    }

    public String reportarRecursos() {
        StringBuilder sb = new StringBuilder("Recursos de " + nombreBrigada + ":");
        for (Recurso r : recursos) sb.append("\n  - ").append(r.reportarDisponibilidad());
        return sb.toString();
    }

    // ---------- Brigadistas ----------
    public void agregarBrigadista(Brigadista b) {
        if (b != null && !brigadistas.contains(b)) {
            brigadistas.add(b);
            b.setBrigadaAsignada(this);
        }
    }

    public int contarBrigadistas() { return brigadistas.size(); }

    // ---------- Recursos ----------
    public void agregarRecurso(Recurso r) {
        if (r != null && !recursos.contains(r)) {
            recursos.add(r);
            r.setBrigada(this);
        }
    }

    // ---------- Getters / Setters ----------
    public int getIdBrigada() { return idBrigada; }
    public void setIdBrigada(int idBrigada) { this.idBrigada = idBrigada; }
    public String getNombreBrigada() { return nombreBrigada; }
    public void setNombreBrigada(String nombreBrigada) { this.nombreBrigada = nombreBrigada; }
    public String getUbicacionActual() { return ubicacionActual; }
    public void setUbicacionActual(String ubicacionActual) { this.ubicacionActual = ubicacionActual; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    public int getCapacidadTotal() { return capacidadTotal; }
    public void setCapacidadTotal(int capacidadTotal) { this.capacidadTotal = capacidadTotal; }
    public Incendio getIncendio() { return incendio; }
    public void setIncendio(Incendio incendio) { this.incendio = incendio; }
    public List<Brigadista> getBrigadistas() { return brigadistas; }
    public List<Recurso> getRecursos() { return recursos; }
}

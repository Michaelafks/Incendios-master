package incendios.Modelo;

import java.util.ArrayList;
import java.util.List;

public class SectorPoblado {
    private String nombreSector;
    private int poblacion;
    private String ubicacion;
    private String estadoEvacuacion;   // Pendiente, En proceso, Evacuado

    // Relacion muchos a muchos con Incendio
    private List<Incendio> incendios = new ArrayList<>();

    public SectorPoblado(String nombreSector, int poblacion, String ubicacion, String estadoEvacuacion) {
        this.nombreSector = nombreSector;
        this.poblacion = poblacion;
        this.ubicacion = ubicacion;
        this.estadoEvacuacion = estadoEvacuacion;
    }

    public void agregarIncendio(Incendio incendio) {
        if (incendio != null && !incendios.contains(incendio)) {
            incendios.add(incendio);
            incendio.agregarSectorPoblado(this);
        }
    }

    public int contarIncendios() { return incendios.size(); }

    public String monitorearAmenaza() {
        return nombreSector + " amenazado por " + incendios.size() + " incendio(s)";
    }

    public String alertarPoblacion() {
        return "ALERTA en " + nombreSector + ": " + poblacion + " personas";
    }

    public void evacuarSector() { this.estadoEvacuacion = "Evacuado"; }

    public String reportarSituacion() {
        return nombreSector + " | poblacion: " + poblacion + " | evacuacion: " + estadoEvacuacion;
    }

    public String getNombreSector() { return nombreSector; }
    public void setNombreSector(String nombreSector) { this.nombreSector = nombreSector; }
    public int getPoblacion() { return poblacion; }
    public void setPoblacion(int poblacion) { this.poblacion = poblacion; }
    public String getUbicacion() { return ubicacion; }
    public void setUbicacion(String ubicacion) { this.ubicacion = ubicacion; }
    public String getEstadoEvacuacion() { return estadoEvacuacion; }
    public void setEstadoEvacuacion(String estadoEvacuacion) { this.estadoEvacuacion = estadoEvacuacion; }
    public List<Incendio> getIncendios() { return incendios; }
}

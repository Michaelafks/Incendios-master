package incendios.Interfaz;

import incendios.Modelo.*;
import incendios.utilitario.Validacion;

import java.time.LocalDate;
import java.util.List;

public class MainIncendios {

    private static GestorIncendios gestor = new GestorIncendios();

    public static void main(String[] args) {
        int opc;
        do {
            menu();
            opc = Validacion.leerEnteroEntre("Ingrese una opcion", 0, 14);
            switch (opc) {
                case 1: registrarIncendio(); break;
                case 2: registrarBrigada(); break;
                case 3: registrarBrigadista(); break;
                case 4: registrarSector(); break;
                case 5: registrarRecurso(); break;
                case 6: asignarBrigadaAIncendio(); break;
                case 7: asignarSectorAIncendio(); break;
                case 8: asignarRecursoAIncendio(); break;
                case 9: listarIncendios(); break;
                case 10: consultasIncendio(); break;
                case 11: historialRecurso(); break;
                case 12: evacuarSector(); break;
                case 13: actualizarEstadoIncendio(); break;
                case 14: listarSectores(); break;
                case 0: System.out.println("Saliendo del Sistema de Control de Incendios..."); break;
            }
        } while (opc != 0);
    }

    public static void menu() {
        System.out.println();
        System.out.println("********** Control de Incendios Forestales **********");
        System.out.println(" 1. Registrar incendio");
        System.out.println(" 2. Registrar brigada");
        System.out.println(" 3. Registrar brigadista (en una brigada)");
        System.out.println(" 4. Registrar sector poblado");
        System.out.println(" 5. Registrar recurso (pesado / manual)");
        System.out.println(" 6. Asignar brigada a incendio");
        System.out.println(" 7. Asignar sector poblado a incendio");
        System.out.println(" 8. Asignar recurso a incendio");
        System.out.println(" 9. Listar incendios");
        System.out.println("10. Consultas y reportes de un incendio");
        System.out.println("11. Historial de asignaciones de un recurso");
        System.out.println("12. Evacuar sector");
        System.out.println("13. Actualizar estado de un incendio");
        System.out.println("14. Listar sectores poblados");
        System.out.println(" 0. Salir");
    }

    // =============== REGISTROS ===============

    public static void registrarIncendio() {
        System.out.println("******* Registro de incendio *******");
        int id = Validacion.leerEnteroPositivo("Ingrese el id del incendio");
        if (gestor.buscarIncendio(id) != null) {
            System.out.println("Ya existe un incendio con el id " + id);
            return;
        }
        String ubicacion = Validacion.leerString("Ingrese la ubicacion");
        String estado = Validacion.leerOpcion("Estado del incendio:", "Activo", "Controlado", "Extinguido");
        float severidad = calcularIEP();
        LocalDate fecha = Validacion.leerFecha("Ingrese la fecha de inicio");

        if (gestor.agregarIncendio(new Incendio(id, ubicacion, estado, severidad, fecha))) {
            System.out.println("Incendio registrado. IEP = " + severidad);
        } else {
            System.out.println("No fue posible registrar el incendio");
        }
    }

    /** RF02: IEP = V_veg x (T/20 + W/15). */
    private static float calcularIEP() {
        System.out.println("-- Calculo del Indice Estimado de Propagacion (IEP) --");
        String veg = Validacion.leerOpcion("Tipo de vegetacion:",
                "Paramo / matorral seco (1.5)", "Bosque de eucalipto / pino (1.3)",
                "Pastizal (1.1)", "Vegetacion humeda (0.7)");
        double factor = veg.contains("1.5") ? 1.5 : veg.contains("1.3") ? 1.3 : veg.contains("1.1") ? 1.1 : 0.7;
        double temp = Validacion.leerDoubleEntre("Temperatura en grados C (-10 a 50)", -10, 50);
        double viento = Validacion.leerDoubleEntre("Velocidad del viento en km/h (0 a 150)", 0, 150);
        return (float) (factor * (temp / 20 + viento / 15));
    }

    public static void registrarBrigada() {
        System.out.println("******* Registro de brigada *******");
        int id = Validacion.leerEnteroPositivo("Ingrese el id de la brigada");
        if (gestor.buscarBrigada(id) != null) {
            System.out.println("Ya existe una brigada con el id " + id);
            return;
        }
        String nombre = Validacion.leerString("Ingrese el nombre de la brigada");
        String ubicacion = Validacion.leerString("Ingrese la ubicacion actual");
        String estado = Validacion.leerOpcion("Estado de la brigada:", "Disponible", "Movilizada", "Descanso");
        int capacidad = Validacion.leerEnteroEntre("Ingrese la capacidad total (1 a 500)", 1, 500);

        if (gestor.agregarBrigada(new Brigada(id, nombre, ubicacion, estado, capacidad))) {
            System.out.println("Brigada registrada con exito");
        } else {
            System.out.println("No fue posible registrar la brigada");
        }
    }

    public static void registrarBrigadista() {
        System.out.println("******* Registro de brigadista *******");
        Brigada brigada = pedirBrigada();
        if (brigada == null) return;
        int id = Validacion.leerEnteroPositivo("Ingrese el id del brigadista");
        if (gestor.buscarBrigadista(id) != null) {
            System.out.println("Ya existe un brigadista con el id " + id);
            return;
        }
        String nombre = Validacion.leerString("Ingrese el nombre");
        String especialidad = Validacion.leerString("Ingrese la especialidad");
        String estado = Validacion.leerOpcion("Condicion fisica:", "Apto", "Fatiga Leve", "Lesionado/No Apto");

        Brigadista b = new Brigadista(id, nombre, especialidad, estado);
        if (gestor.agregarBrigadista(b)) {
            brigada.agregarBrigadista(b);
            System.out.println("Brigadista registrado en la brigada " + brigada.getNombreBrigada());
        } else {
            System.out.println("No fue posible registrar el brigadista");
        }
    }

    public static void registrarSector() {
        System.out.println("******* Registro de sector poblado *******");
        String nombre = Validacion.leerString("Ingrese el nombre del sector");
        if (gestor.buscarSector(nombre) != null) {
            System.out.println("Ya existe el sector " + nombre);
            return;
        }
        int poblacion = Validacion.leerEnteroPositivo("Ingrese la poblacion");
        String ubicacion = Validacion.leerString("Ingrese la ubicacion");
        String estado = Validacion.leerOpcion("Estado de evacuacion:", "Pendiente", "En proceso", "Evacuado");

        if (gestor.agregarSector(new SectorPoblado(nombre, poblacion, ubicacion, estado))) {
            System.out.println("Sector registrado con exito");
        } else {
            System.out.println("No fue posible registrar el sector");
        }
    }

    public static void registrarRecurso() {
        System.out.println("******* Registro de recurso *******");
        int id = Validacion.leerEnteroPositivo("Ingrese el id del recurso");
        if (gestor.buscarRecurso(id) != null) {
            System.out.println("Ya existe un recurso con el id " + id);
            return;
        }
        String tipo = Validacion.leerOpcion("Tipo de recurso:", "Pesado (vehiculo)", "Manual");
        String estado = Validacion.leerOpcion("Estado del recurso:", "Disponible", "En uso", "Mantenimiento");
        String ubicacion = Validacion.leerString("Ingrese la ubicacion");

        Recurso r;
        if (tipo.startsWith("Pesado")) {
            String modelo = Validacion.leerString("Ingrese el modelo del vehiculo");
            String tipoVeh = Validacion.leerOpcion("Tipo de vehiculo:", "Autobomba", "Camion cisterna", "Otro");
            double carga = Validacion.leerDoublePositivo("Ingrese la capacidad de carga (litros)");
            r = new RecursoPesado(id, estado, ubicacion, modelo, (float) carga, tipoVeh);
        } else {
            String lista = Validacion.leerString("Ingrese las herramientas separadas por coma");
            String[] herramientas = lista.split("\\s*,\\s*");
            int operarios = Validacion.leerEnteroEntre("Ingrese la cantidad de operarios (1 a 100)", 1, 100);
            String equipo = Validacion.leerString("Ingrese el equipo de seguridad");
            r = new RecursoManual(id, estado, ubicacion, herramientas, operarios, equipo);
        }

        if (gestor.agregarRecurso(r)) {
            System.out.println("Recurso registrado");
            if (!gestor.getBrigadas().isEmpty()
                    && Validacion.leerOpcion("Asignarlo a una brigada?", "Si", "No").equals("Si")) {
                Brigada b = pedirBrigada();
                if (b != null) {
                    b.agregarRecurso(r);
                    System.out.println("Recurso asignado a la brigada " + b.getNombreBrigada());
                }
            }
        } else {
            System.out.println("No fue posible registrar el recurso");
        }
    }

    // =============== ASIGNACIONES ===============

    public static void asignarBrigadaAIncendio() {
        Incendio inc = pedirIncendio();
        if (inc == null) return;
        Brigada b = pedirBrigada();
        if (b == null) return;
        if (b.getIncendio() != null && b.getIncendio() != inc) {
            System.out.println("La brigada ya atiende el incendio #" + b.getIncendio().getIdIncendio());
            return;
        }
        inc.agregarBrigada(b);
        b.movilizar();
        System.out.println("Brigada " + b.getNombreBrigada() + " atiende ahora el incendio #" + inc.getIdIncendio());
    }

    public static void asignarSectorAIncendio() {
        Incendio inc = pedirIncendio();
        if (inc == null) return;
        SectorPoblado s = pedirSector();
        if (s == null) return;
        inc.agregarSectorPoblado(s);
        System.out.println("Sector " + s.getNombreSector() + " afectado por el incendio #" + inc.getIdIncendio());
    }

    public static void asignarRecursoAIncendio() {
        Incendio inc = pedirIncendio();
        if (inc == null) return;
        Recurso r = pedirRecurso();
        if (r == null) return;
        LocalDate fecha = Validacion.leerFecha("Ingrese la fecha de inicio de la asignacion");
        inc.asignarRecurso(r, fecha);
        r.utilizarRecurso();
        System.out.println("Recurso #" + r.getIdRecurso() + " asignado al incendio #" + inc.getIdIncendio());
    }

    // =============== LISTADOS Y CONSULTAS ===============

    public static void listarIncendios() {
        if (gestor.getIncendios().isEmpty()) {
            System.out.println("No existe ningun incendio aun");
            return;
        }
        for (Incendio i : gestor.getIncendios()) {
            System.out.println(i.reportarIncendio());
        }
    }

    public static void listarSectores() {
        if (gestor.getSectores().isEmpty()) {
            System.out.println("No existe ningun sector aun");
            return;
        }
        for (SectorPoblado s : gestor.getSectores()) {
            System.out.println(s.reportarSituacion() + " | incendios: " + s.contarIncendios());
        }
    }

    public static void consultasIncendio() {
        Incendio inc = pedirIncendio();
        if (inc == null) return;
        int opc;
        do {
            System.out.println("---- Consultas del incendio #" + inc.getIdIncendio() + " ----");
            System.out.println("1. Reporte general");
            System.out.println("2. Cantidad de brigadas y brigada de mayor capacidad");
            System.out.println("3. Buscar brigadas por estado");
            System.out.println("4. Buscar brigadas por capacidad minima");
            System.out.println("5. Listado de brigadistas");
            System.out.println("6. Sectores, evacuados y poblacion");
            System.out.println("7. Recursos y vehiculos");
            System.out.println("8. Progreso del incendio");
            System.out.println("0. Volver");
            opc = Validacion.leerEnteroEntre("Ingrese una opcion", 0, 8);
            switch (opc) {
                case 1:
                    System.out.println(inc.generarReporte());
                    break;
                case 2: {
                    System.out.println("Brigadas atendiendo: " + inc.contarBrigadas());
                    Brigada mayor = inc.obtenerBrigadaMayorCapacidad();
                    System.out.println("Mayor capacidad: " + (mayor == null ? "N/A"
                            : mayor.getNombreBrigada() + " (" + mayor.getCapacidadTotal() + ")"));
                    break;
                }
                case 3: {
                    String e = Validacion.leerOpcion("Estado:", "Disponible", "Movilizada", "Descanso");
                    imprimirBrigadas(inc.buscarBrigadasPorEstado(e));
                    break;
                }
                case 4: {
                    int min = Validacion.leerEnteroPositivo("Capacidad minima");
                    imprimirBrigadas(inc.buscarBrigadasPorCapacidadMinima(min));
                    break;
                }
                case 5: {
                    List<Brigadista> lista = inc.listarBrigadistas();
                    if (lista.isEmpty()) System.out.println("No hay brigadistas");
                    for (Brigadista b : lista) System.out.println(b.reportarEstado());
                    break;
                }
                case 6:
                    System.out.println("Sectores afectados: " + inc.contarSectores());
                    System.out.println("Sectores evacuados: " + inc.contarSectoresEvacuados());
                    System.out.println("Poblacion total: " + inc.calcularPoblacionTotal());
                    System.out.println("Personas aun afectadas: " + inc.calcularPersonasAfectadas());
                    break;
                case 7:
                    System.out.println("Recursos: " + inc.contarRecursos());
                    System.out.println("Vehiculos: " + inc.contarVehiculos());
                    for (Recurso r : inc.listarRecursos()) System.out.println("  - " + r.reportarDisponibilidad());
                    break;
                case 8:
                    System.out.println(inc.monitorearProgreso());
                    break;
            }
        } while (opc != 0);
    }

    private static void imprimirBrigadas(List<Brigada> lista) {
        if (lista.isEmpty()) {
            System.out.println("Ninguna brigada cumple el criterio");
            return;
        }
        for (Brigada b : lista) {
            System.out.println(b.informarEstado() + " | capacidad: " + b.getCapacidadTotal());
        }
    }

    public static void historialRecurso() {
        Recurso r = pedirRecurso();
        if (r == null) return;
        System.out.println(r.reportarDisponibilidad());
        System.out.println("Asignaciones: " + r.contarAsignaciones());
        if (r.contarAsignaciones() > 0) {
            AsignacionRecurso p = r.obtenerPrimeraAsignacion();
            AsignacionRecurso u = r.obtenerUltimaAsignacion();
            System.out.println("Primera: incendio #" + p.getIncendio().getIdIncendio() + " el " + p.getFechaInicio());
            System.out.println("Ultima : incendio #" + u.getIncendio().getIdIncendio() + " el " + u.getFechaInicio());
        }
    }

    public static void evacuarSector() {
        SectorPoblado s = pedirSector();
        if (s == null) return;
        s.evacuarSector();
        System.out.println(s.reportarSituacion());
    }

    public static void actualizarEstadoIncendio() {
        Incendio inc = pedirIncendio();
        if (inc == null) return;
        inc.actualizarEstado(Validacion.leerOpcion("Nuevo estado:", "Activo", "Controlado", "Extinguido"));
        System.out.println(inc.reportarIncendio());
    }

    // =============== BUSQUEDAS AUXILIARES ===============

    private static Incendio pedirIncendio() {
        if (gestor.getIncendios().isEmpty()) {
            System.out.println("Primero registre un incendio");
            return null;
        }
        Incendio i = gestor.buscarIncendio(Validacion.leerEntero("Ingrese el id del incendio"));
        if (i == null) System.out.println("No se encontro el incendio");
        return i;
    }

    private static Brigada pedirBrigada() {
        if (gestor.getBrigadas().isEmpty()) {
            System.out.println("Primero registre una brigada");
            return null;
        }
        Brigada b = gestor.buscarBrigada(Validacion.leerEntero("Ingrese el id de la brigada"));
        if (b == null) System.out.println("No se encontro la brigada");
        return b;
    }

    private static SectorPoblado pedirSector() {
        if (gestor.getSectores().isEmpty()) {
            System.out.println("Primero registre un sector poblado");
            return null;
        }
        SectorPoblado s = gestor.buscarSector(Validacion.leerString("Ingrese el nombre del sector"));
        if (s == null) System.out.println("No se encontro el sector");
        return s;
    }

    private static Recurso pedirRecurso() {
        if (gestor.getRecursos().isEmpty()) {
            System.out.println("Primero registre un recurso");
            return null;
        }
        Recurso r = gestor.buscarRecurso(Validacion.leerEntero("Ingrese el id del recurso"));
        if (r == null) System.out.println("No se encontro el recurso");
        return r;
    }
}

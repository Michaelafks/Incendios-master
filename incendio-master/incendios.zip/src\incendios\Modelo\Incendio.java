package incendios.Modelo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/** Clase con mayor carga: de ella parten mas relaciones, por eso concentra las consultas. */
public class Incendio {
    private int idIncendio;
    private String ubicacion;
    private String estado;        // Activo, Controlado, Extinguido
    private float severidad;      // IEP (indice estimado de propagacion)
    private LocalDate fechaInicio;

    // Relaciones
    private List<Brigada> brigadas = new ArrayList<>();                    // 1 -> 0..*
    private List<SectorPoblado> sectoresAfectados = new ArrayList<>();     // 0..* <-> 0..*
    private List<AsignacionRecurso> asignaciones = new ArrayList<>();      // 1 -> 0..*

    public Incendio(int idIncendio, String ubicacion, String estado, float severidad, LocalDate fechaInicio) {
        this.idIncendio = idIncendio;
        this.ubicacion = ubicacion;
        this.estado = estado;
        this.severidad = severidad;
        this.fechaInicio = fechaInicio;
    }

    // ---------- Metodos propios ----------
    public String reportarIncendio() {
        return "Incendio #" + idIncendio + " en " + ubicacion + " | estado: " + estado
                + " | severidad: " + evaluarSeveridad() + " | inicio: " + fechaInicio;
    }

    public void actualizarEstado(String nuevoEstado) {
        this.estado = nuevoEstado;
    }

    /** Umbrales de RF02: Bajo < 1.8, Medio 1.8-3.2, Critico > 3.2 */
    public String evaluarSeveridad() {
        if (severidad < 1.8f) return "Bajo";
        if (severidad <= 3.2f) return "Medio";
        return "Critico";
    }

    public String monitorearProgreso() {
        return "Incendio #" + idIncendio + " [" + estado + "] brigadas=" + contarBrigadas()
                + ", sectores=" + contarSectores() + ", evacuados=" + contarSectoresEvacuados()
                + ", recursos=" + contarRecursos();
    }

    // ---------- Brigadas ----------
    public void agregarBrigada(Brigada brigada) {
        if (brigada != null && !brigadas.contains(brigada)) {
            brigadas.add(brigada);
            brigada.setIncendio(this);
        }
    }

    public void quitarBrigada(Brigada brigada) {
        if (brigadas.remove(brigada)) {
            brigada.setIncendio(null);
        }
    }

    public Brigada buscarBrigadaPorId(int idBrigada) {
        return brigadas.stream().filter(b -> b.getIdBrigada() == idBrigada).findFirst().orElse(null);
    }

    public List<Brigada> buscarBrigadasPorEstado(String estadoBrigada) {
        return brigadas.stream()
                .filter(b -> b.getEstado().equalsIgnoreCase(estadoBrigada))
                .collect(Collectors.toList());
    }

    public List<Brigada> buscarBrigadasPorCapacidadMinima(int capacidadMin) {
        return brigadas.stream()
                .filter(b -> b.getCapacidadTotal() >= capacidadMin)
                .collect(Collectors.toList());
    }

    public int contarBrigadas() {
        return brigadas.size();
    }

    public Brigada obtenerBrigadaMayorCapacidad() {
        return brigadas.stream().max(Comparator.comparingInt(Brigada::getCapacidadTotal)).orElse(null);
    }

    public List<Brigadista> listarBrigadistas() {
        List<Brigadista> todos = new ArrayList<>();
        for (Brigada b : brigadas) {
            todos.addAll(b.getBrigadistas());
        }
        return todos;
    }

    public int contarBrigadistas() {
        return listarBrigadistas().size();
    }

    // ---------- Sectores poblados ----------
    public void agregarSectorPoblado(SectorPoblado sector) {
        if (sector != null && !sectoresAfectados.contains(sector)) {
            sectoresAfectados.add(sector);
            sector.agregarIncendio(this);
        }
    }

    public SectorPoblado buscarSectorPorNombre(String nombre) {
        return sectoresAfectados.stream()
                .filter(s -> s.getNombreSector().equalsIgnoreCase(nombre))
                .findFirst().orElse(null);
    }

    public int contarSectores() {
        return sectoresAfectados.size();
    }

    public int contarSectoresEvacuados() {
        return (int) sectoresAfectados.stream()
                .filter(s -> s.getEstadoEvacuacion().equalsIgnoreCase("Evacuado"))
                .count();
    }

    public int calcularPoblacionTotal() {
        return sectoresAfectados.stream().mapToInt(SectorPoblado::getPoblacion).sum();
    }

    /** Personas afectadas = poblacion de los sectores que aun no se evacuan. */
    public int calcularPersonasAfectadas() {
        return sectoresAfectados.stream()
                .filter(s -> !s.getEstadoEvacuacion().equalsIgnoreCase("Evacuado"))
                .mapToInt(SectorPoblado::getPoblacion).sum();
    }

    public int calcularPersonasAfectadas(SectorPoblado sector) {
        return sectoresAfectados.contains(sector) ? sector.getPoblacion() : 0;
    }

    // ---------- Recursos (mediante AsignacionRecurso) ----------
    public AsignacionRecurso asignarRecurso(Recurso recurso, LocalDate fechaInicio) {
        AsignacionRecurso asignacion = new AsignacionRecurso(this, recurso, fechaInicio);
        asignaciones.add(asignacion);
        recurso.agregarAsignacion(asignacion);
        return asignacion;
    }

    public List<Recurso> listarRecursos() {
        return asignaciones.stream().map(AsignacionRecurso::getRecurso).distinct().collect(Collectors.toList());
    }

    public int contarRecursos() {
        return listarRecursos().size();
    }

    public int contarRecursosPorTipo(String tipoRecurso) {
        return (int) listarRecursos().stream()
                .filter(r -> r.getTipoRecurso().equalsIgnoreCase(tipoRecurso)).count();
    }

    public int contarVehiculos() {
        return (int) listarRecursos().stream().filter(r -> r instanceof RecursoPesado).count();
    }

    // ---------- Reporte ----------
    public String generarReporte() {
        StringBuilder sb = new StringBuilder();
        sb.append("===== REPORTE INCENDIO #").append(idIncendio).append(" =====\n");
        sb.append(reportarIncendio()).append("\n");
        sb.append("Brigadas atendiendo: ").append(contarBrigadas()).append("\n");
        Brigada mayor = obtenerBrigadaMayorCapacidad();
        sb.append("Brigada de mayor capacidad: ").append(mayor == null ? "N/A" : mayor.getNombreBrigada()).append("\n");
        sb.append("Brigadistas: ").append(contarBrigadistas()).append("\n");
        sb.append("Sectores afectados: ").append(contarSectores())
          .append(" (evacuados: ").append(contarSectoresEvacuados()).append(")\n");
        sb.append("Poblacion total en riesgo: ").append(calcularPoblacionTotal()).append("\n");
        sb.append("Personas aun afectadas: ").append(calcularPersonasAfectadas()).append("\n");
        sb.append("Recursos: ").append(contarRecursos()).append(" (vehiculos: ").append(contarVehiculos()).append(")\n");
        return sb.toString();
    }

    // ---------- Getters / Setters ----------
    public int getIdIncendio() { return idIncendio; }
    public void setIdIncendio(int idIncendio) { this.idIncendio = idIncendio; }
    public String getUbicacion() { return ubicacion; }
    public void setUbicacion(String ubicacion) { this.ubicacion = ubicacion; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    public float getSeveridad() { return severidad; }
    public void setSeveridad(float severidad) { this.severidad = severidad; }
    public LocalDate getFechaInicio() { return fechaInicio; }
    public void setFechaInicio(LocalDate fechaInicio) { this.fechaInicio = fechaInicio; }
    public List<Brigada> getBrigadas() { return brigadas; }
    public List<SectorPoblado> getSectoresAfectados() { return sectoresAfectados; }
    public List<AsignacionRecurso> getAsignaciones() { return asignaciones; }
}
